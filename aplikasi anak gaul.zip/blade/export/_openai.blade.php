@php
    $images         = collect($images);
    $first          = $images->shuffle()->shift();
    $cover_img      = blade_image($keyword,TRUE);
    $max_image      = MAX_IMAGE_RESULT;
    $ads_link       = ADS_LINK;
@endphp
<article>
    @if($first)
    <figure>
        <noscript>
            <img src="{{ $cover_img }}" alt="{{ $first['title'] }}" width="640" height="360" />
        </noscript>
        <img class="v-cover ads-img" src="{{ $cover_img }}" alt="{{ $first['title'] }}" width="100%" style="margin-right: 8px;margin-bottom: 8px;" />
        <figcaption>{{ $first['title'] }} from {{ $first['domain'] }}</figcaption>
    </figure>
    @endif
    {!! $sentences !!}
</article>
<!--more-->
<section>
@foreach($images->shuffle()->take($max_image) as $image)
    <aside>
        <img alt="{{ $image['title'] }}" src="{{ cdn_image($image['url']) }}" width="100%" style="margin-right: 8px;margin-bottom: 8px;" />
        <small>Source: <i>{{ $image['domain'] }}</i></small>
        @if(strpos($ads_link, '//') !== false)
        <center>
            <button class="btn btn-sm btn-success ads-img">Check Details</button>
        </center>
        @endif
    </aside>
@endforeach
</section>
