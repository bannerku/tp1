---
title: "{{ $title }}"
description: "{{ $descTxt }}"
date: "{{ $publishDate }}"
categories:
  - "{{ $niche }}"
images: 
  - "{{ $image }}"
featuredImage: "{{ $image }}"
featured_image: "{{ $image }}"
image: "{{ $image }}"
---

