<h1>Privacy Policy</h1>
<p style="text-align: justify;">The following is the privacy policy of google, so with that I will implement on my blog by e-mail address&nbsp;{{SITE_AUTHOR}}.service@gmail.com.</p>
<p style="text-align: justify;">Last modified: March 1, 2012 (<a href="http://www.google.com/policies/privacy/archive/" rel="nofollow">view archived versions</a>)</p>
<p style="text-align: justify;">There are many different ways you can use our services – to search for and share information, to communicate with other people or to create new content. When you share information with us, for example by creating a&nbsp;<a href="http://www.google.com/policies/privacy/key-terms/#toc-terms-account" rel="nofollow">Google Account</a>, we can make those services even better – to show you more relevant search results and ads, to help you connect with people or to make sharing with others quicker and easier. As you use our services, we want you to be clear how we’re using information and the ways in which you can protect your privacy.</p>
<p style="text-align: justify;">Our Privacy Policy explains:</p>
<ul style="text-align: justify;">
	<li>What information we collect and why we collect it.</li>
	<li>How we use that information.</li>
	<li>The choices we offer, including how to access and update information.</li>
</ul>
<p style="text-align: justify;">We’ve tried to keep it as simple as possible, but if you’re not familiar with terms like cookies, IP addresses, pixel tags and browsers, then read about these&nbsp;<a href="http://www.google.com/policies/privacy/key-terms/" rel="nofollow">key terms</a>&nbsp;first. Your privacy matters to Google so whether you are new to Google or a long-time user, please do take the time to get to know our practices – and if you have any questions&nbsp;<a href="http://www.google.com/support/websearch/bin/answer.py?answer=151265&amp;hl=en" rel="nofollow">contact us</a>.</p>
<h3 id="infocollect" style="text-align: justify;">Information we collect</h3>
<p style="text-align: justify;">We collect information to provide better services to all of our users – from figuring out basic stuff like which language you speak, to more complex things like which ads you’ll find most useful or the people who matter most to you online.</p>
<p style="text-align: justify;">We collect information in two ways:</p>
<ul style="text-align: justify;">
	<li>Information you give us.&nbsp;For example, many of our services require you to sign up for a Google Account. When you do, we’ll ask for&nbsp;<a href="http://www.google.com/policies/privacy/key-terms/#toc-terms-personal-info" rel="nofollow">personal information</a>, like your name, email address, telephone number or credit card. If you want to take full advantage of the sharing features we offer, we might also ask you to create a publicly visible&nbsp;<a href="http://support.google.com/accounts/bin/answer.py?hl=en&amp;answer=112783" rel="nofollow">Google Profile</a>, which may include your name and photo.</li>
	<li>Information we get from your use of our services.&nbsp;We may collect information about the services that you use and how you use them, like when you visit a website that uses our advertising services or you view and interact with our ads and content. This information includes:
		<ul>
			<li>Device informationWe may collect device-specific information (such as your hardware model, operating system version, unique device identifiers, and mobile network information including phone number). Google may associate your device identifiers or phone number with your Google Account.</li>
			<li>Log informationWhen you use our services or view content provided by Google, we may automatically collect and store certain information in&nbsp;<a href="http://www.google.com/policies/privacy/key-terms/#toc-terms-server-logs" rel="nofollow">server logs</a>. This may include:
				<ul>
					<li>details of how you used our service, such as your search queries.</li>
					<li>telephony log information like your phone number, calling-party number, forwarding numbers, time and date of calls, duration of calls, SMS routing information and types of calls.</li>
					<li><a href="http://www.google.com/policies/privacy/key-terms/#toc-terms-ip" rel="nofollow">Internet protocol address</a>.</li>
					<li>device event information such as crashes, system activity, hardware settings, browser type, browser language, the date and time of your request and referral URL.</li>
					<li>cookies that may uniquely identify your browser or your Google Account.</li>
				</ul>
			</li>
			<li>Location informationWhen you use a location-enabled Google service, we may collect and process information about your actual location, like GPS signals sent by a mobile device. We may also use various technologies to determine location, such as sensor data from your device that may, for example, provide information on nearby Wi-Fi access points and cell towers.</li>
			<li>Unique application numbersCertain services include a unique application number. This number and information about your installation (for example, the operating system type and application version number) may be sent to Google when you install or uninstall that service or when that service periodically contacts our servers, such as for automatic updates.</li>
			<li>Local storageWe may collect and store information (including personal information) locally on your device using mechanisms such as browser web storage (including HTML&nbsp;5) and application data caches.</li>
			<li>Cookies and anonymous identifiersWe use various technologies to collect and store information when you visit a Google service, and this may include sending one or more&nbsp;<a href="http://www.google.com/policies/privacy/key-terms/#toc-terms-cookie" rel="nofollow">cookies</a>&nbsp;or&nbsp;<a href="http://www.google.com/policies/privacy/key-terms/#toc-terms-identifier" rel="nofollow">anonymous identifiers</a>&nbsp;to your device. We also use cookies and anonymous identifiers when you interact with services we offer to our partners, such as advertising services or Google features that may appear on other sites.</li>
		</ul>
	</li>
</ul>
<h3 id="infouse" style="text-align: justify;">How we use information we collect</h3>
<p style="text-align: justify;">We use the information we collect from all of our services to provide, maintain, protect and improve them, to develop new ones, and to protect Google and our users. We also use this information to offer you tailored content – like giving you more relevant search results and ads.</p>
<p style="text-align: justify;">We may use the name you provide for your Google Profile across all of the services we offer that require a Google Account. In addition, we may replace past names associated with your Google Account so that you are represented consistently across all our services. If other users already have your email, or other information that identifies you, we may show them your publicly visible Google Profile information, such as your name and photo.</p>
<p style="text-align: justify;">When you contact Google, we may keep a record of your communication to help solve any issues you might be facing. We may use your email address to inform you about our services, such as letting you know about upcoming changes or improvements.</p>
<p style="text-align: justify;">We use information collected from cookies and other technologies, like&nbsp;<a href="http://www.google.com/policies/privacy/key-terms/#toc-terms-pixel" rel="nofollow">pixel tags</a>, to improve your user experience and the overall quality of our services. For example, by saving your language preferences, we’ll be able to have our services appear in the language you prefer. When showing you tailored ads, we will not associate a cookie or anonymous identifier with sensitive categories, such as those based on race, religion, sexual orientation or health.</p>
<p style="text-align: justify;">We may combine personal information from one service with information, including personal information, from other Google services – for example to make it easier to share things with people you know. We will not combine DoubleClick cookie information with personally identifiable information unless we have your opt-in consent.</p>
<p style="text-align: justify;">We will ask for your consent before using information for a purpose other than those that are set out in this Privacy Policy.</p>
<p style="text-align: justify;">Google processes personal information on our servers in many countries around the world. We may process your personal information on a server located outside the country where you live.</p>
<h3 id="infochoices" style="text-align: justify;">Transparency and choice</h3>
<p style="text-align: justify;">People have different privacy concerns. Our goal is to be clear about what information we collect, so that you can make meaningful choices about how it is used. For example, you can:</p>
<ul style="text-align: justify;">
	<li><a href="https://www.google.com/dashboard/?hl=en" rel="nofollow">Review and control</a>&nbsp;certain types of information tied to your Google Account by using Google Dashboard.</li>
	<li><a href="https://www.google.com/settings/ads/preferences?hl=en" rel="nofollow">View and edit</a>&nbsp;your ads preferences, such as which categories might interest you, using the Ads Preferences Manager. You can also opt out of certain Google advertising services here.</li>
	<li><a href="http://support.google.com/accounts/bin/answer.py?hl=en&amp;answer=97706" rel="nofollow">Use our editor</a>&nbsp;to see and adjust how your Google Profile appears to particular individuals.</li>
	<li><a href="http://support.google.com/plus/bin/static.py?hl=en&amp;page=guide.cs&amp;guide=1257347" rel="nofollow">Control</a>&nbsp;who you share information with.</li>
	<li><a href="http://www.dataliberation.org/" rel="nofollow">Take information</a>&nbsp;out of many of our services.</li>
</ul>
<p style="text-align: justify;">You may also set your browser to block all cookies, including cookies associated with our services, or to indicate when a cookie is being set by us. However, it’s important to remember that many of our services may not function properly if your cookies are disabled. For example, we may not remember your language preferences.</p>
<h3 id="infosharing" style="text-align: justify;">Information you share</h3>
<p style="text-align: justify;">Many of our services let you share information with others. Remember that when you share information publicly, it may be indexable by search engines, including Google. Our services provide you with different options on sharing and removing your content.</p>
<h3 id="access" style="text-align: justify;">Accessing and updating your personal information</h3>
<p style="text-align: justify;">Whenever you use our services, we aim to provide you with access to your personal information. If that information is wrong, we strive to give you ways to update it quickly or to delete it – unless we have to keep that information for legitimate business or legal purposes. When updating your personal information, we may ask you to verify your identity before we can act on your request.</p>
<p style="text-align: justify;">We may reject requests that are unreasonably repetitive, require disproportionate technical effort (for example, developing a new system or fundamentally changing an existing practice), risk the privacy of others, or would be extremely impractical (for instance, requests concerning information residing on backup tapes).</p>
<p style="text-align: justify;">Where we can provide information access and correction, we will do so for free, except where it would require a disproportionate effort. We aim to maintain our services in a manner that protects information from accidental or malicious destruction. Because of this, after you delete information from our services, we may not immediately delete residual copies from our active servers and may not remove information from our backup systems.</p>
<h3 id="nosharing" style="text-align: justify;">Information we share</h3>
<p style="text-align: justify;">We do not share personal information with companies, organizations and individuals outside of Google unless one of the following circumstances apply:</p>
<ul style="text-align: justify;">
	<li>With your consentWe will share personal information with companies, organizations or individuals outside of Google when we have your consent to do so. We require opt-in consent for the sharing of any&nbsp;<a href="http://www.google.com/policies/privacy/key-terms/#toc-terms-sensitive-info" rel="nofollow">sensitive personal information</a>.</li>
	<li>With domain administratorsIf your Google Account is managed for you by a&nbsp;<a href="http://support.google.com/a/bin/answer.py?hl=en&amp;answer=178897" rel="nofollow">domain administrator</a>&nbsp;(for example, for Google Apps users) then your domain administrator and resellers who provide user support to your organization will have access to your Google Account information (including your email and other data). Your domain administrator may be able to:
		<ul>
			<li>view statistics regarding your account, like statistics regarding applications you install.</li>
			<li>change your account password.</li>
			<li>suspend or terminate your account access.</li>
			<li>access or retain information stored as part of your account.</li>
			<li>receive your account information in order to satisfy applicable law, regulation, legal process or enforceable governmental request.</li>
			<li>restrict your ability to delete or edit information or privacy settings.</li>
		</ul>
		<p>Please refer to your domain administrator’s privacy policy for more information.</p>
	</li>
	<li>For external processingWe provide personal information to our affiliates or other trusted businesses or persons to process it for us, based on our instructions and in compliance with our Privacy Policy and any other appropriate confidentiality and security measures.</li>
	<li>For legal reasonsWe will share personal information with companies, organizations or individuals outside of Google if we have a good-faith belief that access, use, preservation or disclosure of the information is reasonably necessary to:
		<ul>
			<li>meet any applicable law, regulation, legal process or enforceable governmental request.</li>
			<li>enforce applicable Terms of Service, including investigation of potential violations.</li>
			<li>detect, prevent, or otherwise address fraud, security or technical issues.</li>
			<li>protect against harm to the rights, property or safety of Google, our users or the public as required or permitted by law.</li>
		</ul>
	</li>
</ul>
<p style="text-align: justify;">We may share aggregated,&nbsp;<a href="http://www.google.com/policies/privacy/key-terms/#toc-terms-info" rel="nofollow">non-personally identifiable information</a>&nbsp;publicly and with our partners – like publishers, advertisers or connected sites. For example, we may share information publicly to show trends about the general use of our services.</p>
<p style="text-align: justify;">If Google is involved in a merger, acquisition or asset sale, we will continue to ensure the confidentiality of any personal information and give affected users notice before personal information is transferred or becomes subject to a different privacy policy.</p>
<h3 id="infosecurity" style="text-align: justify;">Information security</h3>
<p style="text-align: justify;">We work hard to protect Google and our users from unauthorized access to or unauthorized alteration, disclosure or destruction of information we hold. In particular:</p>
<ul style="text-align: justify;">
	<li>We encrypt many of our services&nbsp;<a href="http://support.google.com/websearch/bin/answer.py?answer=173733&amp;en">using SSL</a>.</li>
	<li>We offer you&nbsp;<a href="http://support.google.com/accounts/bin/static.py?hl=en&amp;page=guide.cs&amp;guide=1056283&amp;topic=1056284" rel="nofollow">two step verification</a>&nbsp;when you access your Google Account, and a&nbsp;<a href="http://www.google.com/chrome/intl/en/more/security.html" rel="nofollow">Safe Browsing feature</a>&nbsp;in Google Chrome.</li>
	<li>We review our information collection, storage and processing practices, including physical security measures, to guard against unauthorized access to systems.</li>
	<li>We restrict access to personal information to Google employees, contractors and agents who need to know that information in order to process it for us, and who are subject to strict contractual confidentiality obligations and may be disciplined or terminated if they fail to meet these obligations.</li>
</ul>
<h3 id="application" style="text-align: justify;">Application</h3>
<p style="text-align: justify;">Our Privacy Policy applies to all of the services offered by Google Inc. and its affiliates, including services offered on other sites (such as our advertising services), but excludes services that have separate privacy policies that do not incorporate this Privacy Policy.</p>
<p style="text-align: justify;">Our Privacy Policy does not apply to services offered by other companies or individuals, including products or sites that may be displayed to you in search results, sites that may include Google services, or other sites linked from our services. Our Privacy Policy does not cover the information practices of other companies and organizations who advertise our services, and who may use cookies, pixel tags and other technologies to serve and offer relevant ads.</p>
<h3 id="enforcement" style="text-align: justify;">Enforcement</h3>
<p style="text-align: justify;">We regularly review our compliance with our Privacy Policy. We also adhere to several&nbsp;<a href="http://www.google.com/policies/privacy/frameworks/" rel="nofollow">self regulatory frameworks</a>. When we receive formal written complaints, we will contact the person who made the complaint to follow up. We work with the appropriate regulatory authorities, including local data protection authorities, to resolve any complaints regarding the transfer of personal data that we cannot resolve with our users directly.</p>
<h3 id="policychanges" style="text-align: justify;">Changes</h3>
<p style="text-align: justify;">Our Privacy Policy may change from time to time. We will not reduce your rights under this Privacy Policy without your explicit consent. We will post any privacy policy changes on this page and, if the changes are significant, we will provide a more prominent notice (including, for certain services, email notification of privacy policy changes). We will also keep prior versions of this Privacy Policy in an archive for your review.</p>
<h3 id="products" style="text-align: justify;">Specific product practices</h3>
<p style="text-align: justify;">The following notices explain specific privacy practices with respect to certain Google products and services that you may use:</p>
<ul style="text-align: justify;">
	<li><a href="http://www.google.com/chrome/intl/en/privacy.html" rel="nofollow">Chrome and Chrome OS</a></li>
	<li><a href="http://books.google.com/intl/en/googlebooks/privacy.html" rel="nofollow">Books</a></li>
	<li><a href="http://wallet.google.com/files/privacy.html?hl=en" rel="nofollow">Wallet</a></li>
</ul>
<p style="text-align: justify;">The contents of this statement may be altered at any time, at our discretion. If you have any questions regarding the privacy policy of&nbsp;image-references.blogspot.com&nbsp;then you may&nbsp;<a href="/p/contact.html">contact us</a>&nbsp;at {{SITE_AUTHOR}}.service@gmail.com.</p>