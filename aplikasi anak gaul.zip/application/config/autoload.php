<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$autoload['packages'] = array();

$autoload['libraries'] = array('session','user_agent');

$autoload['drivers'] = array();

$autoload['helper'] = array('url','file','string','text','dbimake','joox','sparta','openai', 'export_blade');

$autoload['config'] = array();

$autoload['language'] = array();

$autoload['model'] = array();
